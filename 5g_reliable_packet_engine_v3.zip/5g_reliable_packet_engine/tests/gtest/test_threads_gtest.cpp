// Concurrency test, written for `make helgrind`.
// The engine keeps no global/static state, so independent simulations running
// in parallel threads (each with its OWN config/stats/tree) must be race-free.
// Helgrind / ThreadSanitizer should report 0 errors for this test.
#include <gtest/gtest.h>
#include <thread>
#include <vector>

extern "C" {
#include "bst.h"
#include "sliding_window.h"
}

namespace {

TEST(Threads, IndependentSimulationsAreRaceFree)
{
    constexpr int kThreads = 4;
    std::vector<sw_stats_t> stats(kThreads);
    std::vector<status_t> rc(kThreads, STATUS_ERR_STATE);
    std::vector<std::thread> pool;

    for (int i = 0; i < kThreads; ++i) {
        pool.emplace_back([i, &stats, &rc]() {
            sw_config_t cfg;
            sw_config_default(&cfg);
            cfg.packet_count = 60U;
            cfg.data_loss_percent = 10U;
            cfg.seed = 100U + static_cast<uint32_t>(i);
            rc[i] = sw_simulate(&cfg, 1U, 2U, nullptr, &stats[i]);
        });
    }
    for (auto &t : pool) { t.join(); }

    for (int i = 0; i < kThreads; ++i) {
        EXPECT_EQ(STATUS_OK, rc[i]);
        EXPECT_EQ(60U, stats[i].delivered);
    }
}

TEST(Threads, PerThreadStationTrees)
{
    constexpr int kThreads = 4;
    std::vector<uint32_t> counts(kThreads, 0U);
    std::vector<std::thread> pool;

    for (int i = 0; i < kThreads; ++i) {
        pool.emplace_back([i, &counts]() {
            bst_t tree;
            bst_init(&tree);
            for (station_id_t id = 1U; id <= 200U; ++id) {
                station_t s;
                if (station_init(&s, id, "Node", id, 100U, 1U, "Relay") == STATUS_OK) {
                    (void)bst_insert(&tree, &s);
                }
            }
            counts[i] = tree.count;
            bst_destroy(&tree);
        });
    }
    for (auto &t : pool) { t.join(); }
    for (int i = 0; i < kThreads; ++i) { EXPECT_EQ(200U, counts[i]); }
}

}  // namespace
