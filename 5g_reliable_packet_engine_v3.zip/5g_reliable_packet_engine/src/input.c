/* input.c - bounded console input and strict numeric parsing. */
#include <string.h>
#include "input.h"

status_t input_read_line(FILE *in, char *buffer, size_t capacity)
{
    status_t rc = STATUS_OK;

    if ((in == NULL) || (buffer == NULL) || (capacity < 2U) || (capacity > 4096U)) {
        rc = STATUS_ERR_NULL;
    } else if (fgets(buffer, (int)capacity, in) == NULL) {
        buffer[0] = '\0';
        rc = STATUS_ERR_IO;
    } else {
        size_t len = 0U;

        while ((len < capacity) && (buffer[len] != '\0')) {
            len++;
        }
        if ((len > 0U) && (buffer[len - 1U] == '\n')) {
            buffer[len - 1U] = '\0';
            if ((len > 1U) && (buffer[len - 2U] == '\r')) {
                buffer[len - 2U] = '\0';
            }
        } else if (len == (capacity - 1U)) {
            /* Buffer full without newline: exact fit, EOF, or an over-long line. */
            int c = fgetc(in);

            if ((c != '\n') && (c != EOF)) {
                while ((c != '\n') && (c != EOF)) {
                    c = fgetc(in);
                }
                rc = STATUS_ERR_RANGE;
            }
        } else {
            /* last line without trailing newline */
        }
    }
    return rc;
}

status_t input_parse_u32(const char *text, uint32_t min, uint32_t max,
                         uint32_t *value)
{
    status_t rc = STATUS_OK;

    if ((text == NULL) || (value == NULL)) {
        rc = STATUS_ERR_NULL;
    } else {
        size_t start = 0U;
        size_t end = strlen(text);
        uint64_t acc = 0U;

        while ((start < end) && ((text[start] == ' ') || (text[start] == '\t'))) {
            start++;
        }
        while ((end > start) && ((text[end - 1U] == ' ') || (text[end - 1U] == '\t'))) {
            end--;
        }
        if (start == end) {
            rc = STATUS_ERR_FORMAT;        /* empty input */
        } else {
            size_t i = start;

            while ((i < end) && (rc == STATUS_OK)) {
                if ((text[i] < '0') || (text[i] > '9')) {
                    rc = STATUS_ERR_FORMAT;    /* sign, letter, trailing junk ... */
                } else {
                    acc = (acc * 10U) + (uint64_t)(text[i] - '0');
                    if (acc > (uint64_t)UINT32_MAX) {
                        rc = STATUS_ERR_RANGE; /* overflow guard */
                    }
                    i++;
                }
            }
            if (rc == STATUS_OK) {
                if ((acc < (uint64_t)min) || (acc > (uint64_t)max)) {
                    rc = STATUS_ERR_RANGE;
                } else {
                    *value = (uint32_t)acc;
                }
            }
        }
    }
    return rc;
}

status_t input_prompt_u32(FILE *in, FILE *out, const char *prompt,
                          uint32_t min, uint32_t max, uint32_t *value)
{
    status_t result = STATUS_ERR_RANGE;      /* returned when attempts run out */

    if ((in == NULL) || (out == NULL) || (prompt == NULL) || (value == NULL)) {
        result = STATUS_ERR_NULL;
    } else {
        uint32_t attempt = 0U;
        bool done = false;

        while ((attempt < INPUT_MAX_ATTEMPTS) && (!done)) {
            char line[64];
            status_t rc;

            (void)fprintf(out, "%s [%u-%u]: ", prompt, (unsigned)min, (unsigned)max);
            rc = input_read_line(in, line, sizeof(line));
            if (rc == STATUS_ERR_IO) {
                result = STATUS_ERR_IO;
                done = true;
            } else {
                if (rc == STATUS_OK) {
                    rc = input_parse_u32(line, min, max, value);
                }
                if (rc == STATUS_OK) {
                    result = STATUS_OK;
                    done = true;
                } else {
                    (void)fprintf(out, "  Invalid input (%s). Enter digits only, within range.\n",
                                  status_to_string(rc));
                }
            }
            attempt++;
        }
    }
    return result;
}

status_t input_prompt_text(FILE *in, FILE *out, const char *prompt,
                           char *buffer, size_t capacity,
                           input_text_validator_fn validator)
{
    status_t result = STATUS_ERR_RANGE;      /* returned when attempts run out */

    if ((in == NULL) || (out == NULL) || (prompt == NULL) || (buffer == NULL) ||
        (validator == NULL)) {
        result = STATUS_ERR_NULL;
    } else {
        uint32_t attempt = 0U;
        bool done = false;

        while ((attempt < INPUT_MAX_ATTEMPTS) && (!done)) {
            status_t rc;

            (void)fprintf(out, "%s: ", prompt);
            rc = input_read_line(in, buffer, capacity);
            if (rc == STATUS_ERR_IO) {
                result = STATUS_ERR_IO;
                done = true;
            } else {
                if (rc == STATUS_OK) {
                    rc = validator(buffer);
                }
                if (rc == STATUS_OK) {
                    result = STATUS_OK;
                    done = true;
                } else {
                    (void)fprintf(out, "  Invalid text (%s). Allowed: letters, digits, space, - _ .\n",
                                  status_to_string(rc));
                }
            }
            attempt++;
        }
    }
    return result;
}
