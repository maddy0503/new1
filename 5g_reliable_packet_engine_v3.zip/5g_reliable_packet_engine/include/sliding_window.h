/* sliding_window.h - Go-Back-N ARQ sender, receiver and simulation driver.
 *
 * Go-Back-N: sender keeps up to N unacknowledged packets in flight; the
 * receiver accepts ONLY the next expected sequence number (receiver window
 * = 1), discards everything else and re-ACKs. ACKs are cumulative
 * ("ack_seq = next expected"). On timeout the sender goes back and resends
 * every outstanding packet starting from the oldest.
 * (Selective Repeat would buffer out-of-order packets and ACK individually;
 *  it is NOT implemented - see README "Known limitations".)
 */
#ifndef SLIDING_WINDOW_H
#define SLIDING_WINDOW_H

#include <stdio.h>
#include "packet.h"
#include "logger.h"

#define SW_MAX_PACKETS 1000U
#define SW_MAX_TICKS   1000000U
#define SW_PROP_DELAY  1U         /* one-way channel delay in ticks */

typedef struct {
    uint8_t  window_size;         /* 1..SW_WINDOW_MAX                  */
    uint32_t packet_count;        /* 1..SW_MAX_PACKETS                 */
    uint32_t timeout_ticks;       /* 1..100                            */
    uint8_t  max_retries;         /* 1..20 per packet                  */
    uint32_t data_loss_every;     /* drop every Nth data tx (0 = off)  */
    uint32_t ack_loss_every;      /* drop every Nth ACK tx  (0 = off)  */
    uint8_t  data_loss_percent;   /* 0..100, seeded PRNG               */
    uint8_t  ack_loss_percent;    /* 0..100, seeded PRNG               */
    uint32_t seed;                /* fixed seed -> repeatable runs     */
} sw_config_t;

typedef struct {
    uint32_t packets_requested;
    uint32_t data_tx;             /* every data transmission incl. retx */
    uint32_t retransmissions;
    uint32_t data_lost;
    uint32_t data_received;
    uint32_t delivered;           /* in-order deliveries to application */
    uint32_t duplicates;
    uint32_t out_of_order;
    uint32_t acks_sent;
    uint32_t acks_lost;
    uint32_t acks_received;
    uint32_t dup_acks;
    uint32_t timeouts;
    uint32_t ticks;
    char     started_at[LOGGER_TS_LEN];   /* wall-clock start of the run  */
    char     finished_at[LOGGER_TS_LEN];  /* wall-clock end of the run    */
} sw_stats_t;

typedef struct {
    packet_t     slots[SEQ_MODULUS]; /* circular buffer indexed by seq */
    uint32_t     base_abs;           /* oldest unacked (absolute index) */
    uint32_t     next_abs;           /* next new packet (absolute index)*/
    uint32_t     total;
    uint32_t     timer_start;
    uint8_t      window;
    station_id_t src;
    station_id_t dst;
} sw_sender_t;

typedef enum { RX_ACCEPTED = 0, RX_DUPLICATE, RX_OUT_OF_ORDER } rx_result_t;

typedef struct {
    uint8_t  expected_seq;
    uint32_t delivered;
    uint8_t  sender_window;          /* used only to classify duplicates */
} sw_receiver_t;

status_t sw_config_default(sw_config_t *config);
status_t sw_config_validate(const sw_config_t *config);

status_t sw_sender_init(sw_sender_t *sender, uint8_t window, uint32_t total,
                        station_id_t src, station_id_t dst);
uint32_t sw_sender_outstanding(const sw_sender_t *sender);
bool     sw_sender_can_send(const sw_sender_t *sender);
status_t sw_sender_next_packet(sw_sender_t *sender, const uint8_t *payload,
                               size_t length, uint32_t now, packet_t **out);
status_t sw_sender_process_ack(sw_sender_t *sender, uint8_t ack_seq,
                               uint32_t now, uint32_t *advanced);
bool     sw_sender_timed_out(const sw_sender_t *sender, uint32_t now,
                             uint32_t timeout_ticks);
status_t sw_sender_mark_retransmit(sw_sender_t *sender, uint32_t k,
                                   uint8_t max_retries, uint32_t now,
                                   packet_t **out);

status_t sw_receiver_init(sw_receiver_t *receiver, uint8_t sender_window);
status_t sw_receiver_on_packet(sw_receiver_t *receiver, const packet_t *packet,
                               ack_t *ack, rx_result_t *result);

/* Runs a complete deterministic simulation. log may be NULL (silent); every
 * log line starts with a wall-clock timestamp followed by the simulation tick.
 * stats is filled even when an error is returned. */
status_t sw_simulate(const sw_config_t *config, station_id_t src,
                     station_id_t dst, FILE *log, sw_stats_t *stats);
void     sw_print_stats(FILE *out, const sw_stats_t *stats);

#endif /* SLIDING_WINDOW_H */
