/* packet.h - packet / ACK structures, sequence arithmetic, channel queues.
 *
 * Bounded sequence-number model: sequence numbers are 4 bits (0..15), so
 * SEQ_MODULUS = 16 and Go-Back-N allows a sender window of at most 15
 * (MODULUS - 1). Sequence numbers wrap around modulo 16.
 */
#ifndef PACKET_H
#define PACKET_H

#include "station.h"

#define SEQ_MODULUS   16U
#define SW_WINDOW_MAX 15U
#define PAYLOAD_MAX   32U
#define CHANNEL_CAP   64U

typedef enum {
    PKT_STATUS_EMPTY = 0,
    PKT_STATUS_SENT,
    PKT_STATUS_RETRANSMITTED,
    PKT_STATUS_ACKED
} pkt_status_t;

typedef struct {
    uint8_t      seq;
    station_id_t src;
    station_id_t dst;
    uint8_t      payload_len;
    uint8_t      payload[PAYLOAD_MAX];
    uint16_t     checksum;        /* integrity check over header + payload */
    pkt_status_t status;
    uint8_t      retry_count;
    uint32_t     sent_tick;       /* simulation timer value */
} packet_t;

typedef struct {
    uint8_t      ack_seq;         /* cumulative: next sequence expected */
    station_id_t src;             /* receiver station */
    station_id_t dst;             /* original sender station */
} ack_t;

status_t packet_init(packet_t *packet, uint8_t seq, station_id_t src,
                     station_id_t dst, const uint8_t *payload, size_t length);

/* (to - from) modulo SEQ_MODULUS */
uint8_t seq_distance(uint8_t from, uint8_t to);
uint8_t seq_next(uint8_t seq);
/* Recompute the deterministic 16-bit packet checksum; false means invalid. */
uint16_t packet_checksum(const packet_t *packet);
bool packet_verify(const packet_t *packet);

/* Fixed-capacity circular FIFO queues modelling the two channel directions.
 * Each entry carries the tick at which it becomes deliverable.
 * push/pop are O(1); storage is O(CHANNEL_CAP); no dynamic memory. */
typedef struct { packet_t pkt; uint32_t due_tick; } pkt_slot_t;
typedef struct { pkt_slot_t slots[CHANNEL_CAP]; size_t head; size_t count; } pkt_queue_t;

typedef struct { ack_t ack; uint32_t due_tick; } ack_slot_t;
typedef struct { ack_slot_t slots[CHANNEL_CAP]; size_t head; size_t count; } ack_queue_t;

void     pktq_init(pkt_queue_t *queue);
status_t pktq_push(pkt_queue_t *queue, const packet_t *packet, uint32_t due_tick);
bool     pktq_pop_due(pkt_queue_t *queue, uint32_t now, packet_t *out);

void     ackq_init(ack_queue_t *queue);
status_t ackq_push(ack_queue_t *queue, const ack_t *ack, uint32_t due_tick);
bool     ackq_pop_due(ack_queue_t *queue, uint32_t now, ack_t *out);

#endif /* PACKET_H */
