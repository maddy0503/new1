# Coverage Report (measured in this workspace)

Command: `make coverage` using GCC/gcov with `-O0 --coverage`, running all five C test binaries. Counts cover `src/*.c` library modules only; the interactive `src/main.c` menu is excluded because it is not linked into the unit-test binaries (it is exercised by `make demo` / `make functional`).

| File | Lines % | Branch % | Function % |
|---|---:|---:|---:|
| `src/common.c` | 100.00 | 100.00 | 100.0 (1/1) |
| `src/bst.c` | 97.83 | 90.20 | 100.0 (10/10) |
| `src/station.c` | 100.00 | 100.00 | 100.0 (8/8) |
| `src/packet.c` | 100.00 | 96.88 | 100.0 (11/11) |
| `src/sliding_window.c` | 97.84 | 91.53 | 100.0 (22/22) |
| `src/storage.c` | 94.17 | 89.77 | 100.0 (6/6) |
| `src/input.c` | 100.00 | 90.38 | 100.0 (4/4) |
| `src/logger.c` | 94.74 | 90.14 | 100.0 (13/13) |
| **TOTAL** | **97.7** | **92.5** | **100.0** |

(Previous run: 98.2 % line / 89.1 % branch. Branch coverage rose; the line % moved slightly because the new `logger.c`
contains defensive error paths - clock failure, `strftime` failure - that cannot be triggered portably.)

Reproduce: `make coverage`. For annotated output: `gcov -b -o build/cov src/logger.c`.
